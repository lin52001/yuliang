# 余量 Codex 本地插件

版本：0.1.0-beta.1。需要 macOS 14+、Node.js 20+ 和已安装的余量 0.17.0 build 23+。

此包只提供插件。已有兼容 App 无需重复下载；尚未安装后台时，请先查看 [项目安装说明](https://github.com/lin52001/yuliang)。

解压后在本目录执行：

```sh
codex plugin marketplace add .
codex plugin add yuliang@yuliang-local --json
```

重启 Codex 后，在新聊天中使用余量。详情见 [插件指南](docs/YULIANG-PLUGIN.md)。
